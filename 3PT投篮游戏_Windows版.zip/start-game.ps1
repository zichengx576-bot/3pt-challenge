param(
  [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$root = Join-Path $PSScriptRoot 'dist'

if (-not (Test-Path -LiteralPath (Join-Path $root 'index.html'))) {
  throw 'Game files are missing. Keep the dist folder next to this script.'
}

function Get-ContentType([string]$path) {
  switch ([IO.Path]::GetExtension($path).ToLowerInvariant()) {
    '.html' { return 'text/html; charset=utf-8' }
    '.js' { return 'text/javascript; charset=utf-8' }
    '.css' { return 'text/css; charset=utf-8' }
    '.json' { return 'application/json; charset=utf-8' }
    '.svg' { return 'image/svg+xml' }
    '.png' { return 'image/png' }
    '.jpg' { return 'image/jpeg' }
    '.jpeg' { return 'image/jpeg' }
    '.ico' { return 'image/x-icon' }
    '.woff2' { return 'font/woff2' }
    default { return 'application/octet-stream' }
  }
}

$listener = [System.Net.HttpListener]::new()
$port = $null
foreach ($candidatePort in 4173..4183) {
  try {
    $listener.Prefixes.Clear()
    $listener.Prefixes.Add("http://127.0.0.1:$candidatePort/")
    $listener.Start()
    $port = $candidatePort
    break
  } catch {
    if ($listener.IsListening) { $listener.Stop() }
  }
}

if ($null -eq $port) {
  throw 'Could not find a free local port from 4173 to 4183.'
}

$url = "http://127.0.0.1:$port/"
Write-Host "3PT Challenge is running at $url"
Write-Host 'Keep this window open while playing. Close it to stop the game server.'
if (-not $NoBrowser) { Start-Process $url }

try {
  while ($listener.IsListening) {
    $context = $listener.GetContext()
    try {
      $requestPath = [Uri]::UnescapeDataString($context.Request.Url.AbsolutePath).TrimStart('/')
      if ([string]::IsNullOrWhiteSpace($requestPath)) { $requestPath = 'index.html' }
      $relativePath = $requestPath.Replace('/', [IO.Path]::DirectorySeparatorChar)
      $filePath = [IO.Path]::GetFullPath((Join-Path $root $relativePath))
      $rootPath = [IO.Path]::GetFullPath($root) + [IO.Path]::DirectorySeparatorChar

      if (-not $filePath.StartsWith($rootPath, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $filePath -PathType Leaf)) {
        $context.Response.StatusCode = 404
        $bytes = [Text.Encoding]::UTF8.GetBytes('Not found')
        $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
      } else {
        $bytes = [IO.File]::ReadAllBytes($filePath)
        $context.Response.StatusCode = 200
        $context.Response.ContentType = Get-ContentType $filePath
        $context.Response.ContentLength64 = $bytes.Length
        $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
      }
    } catch {
      $context.Response.StatusCode = 500
      $bytes = [Text.Encoding]::UTF8.GetBytes('Server error')
      $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    } finally {
      $context.Response.OutputStream.Close()
      $context.Response.Close()
    }
  }
} finally {
  $listener.Stop()
  $listener.Close()
}
