@echo off
chcp 65001 >nul
title 3PT Challenge
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-game.ps1"
if errorlevel 1 pause
